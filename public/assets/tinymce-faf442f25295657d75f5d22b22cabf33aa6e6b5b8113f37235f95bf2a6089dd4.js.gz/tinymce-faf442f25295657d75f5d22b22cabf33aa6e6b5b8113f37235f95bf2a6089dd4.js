try {
   tinyMCE.init({
       selector: 'textarea.tinymce'
   });
}
catch(e){}
